SELECT Customer_Name, Order_Date
FROM superstore_staging1
ORDER BY Order_Date DESC;