SELECT * 
FROM superstore_staging1;

