SELECT 
    c.Customer_ID,c.Customer_Name,o.Order_ID,o.Order_Date,o.Product_Name,o.Sales,
    COALESCE(o.Quantity, 0) as Quantity
FROM (
    SELECT DISTINCT Customer_ID, Customer_Name 
    FROM dbo.superstore_staging1
) c
LEFT JOIN dbo.superstore_staging1 o 
    ON c.Customer_ID = o.Customer_ID
ORDER BY c.Customer_Name, o.Order_Date;