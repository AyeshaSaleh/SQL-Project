SELECT Customer_Name, City, Segment
FROM superstore_staging1;