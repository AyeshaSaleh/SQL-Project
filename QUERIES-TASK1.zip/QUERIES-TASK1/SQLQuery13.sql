SELECT 
    p.Product_ID,p.Product_Name,p.Category,p.Sub_Category,s.Order_ID,s.Order_Date,s.Sales,
    COALESCE(s.Quantity, 0) as Quantity,
    COALESCE(s.Profit, 0) as Profit
FROM (
    SELECT DISTINCT Product_ID, Product_Name, Category, Sub_Category 
    FROM dbo.superstore_staging1
) p
RIGHT JOIN dbo.superstore_staging1 s 
    ON p.Product_ID = s.Product_ID
ORDER BY p.Product_Name, s.Order_Date;