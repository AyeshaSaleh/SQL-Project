WITH MonthlySales AS (
    SELECT 
        YEAR(Order_Date) as SalesYear,
        MONTH(Order_Date) as SalesMonth,
        Segment,
        Product_ID,
        Product_Name,
        Category,
        SUM(Sales) as TotalSales,
        SUM(Quantity) as TotalQuantity,
        SUM(Profit) as TotalProfit,
        COUNT(Order_ID) as OrderCount,
        ROW_NUMBER() OVER (PARTITION BY YEAR(Order_Date), MONTH(Order_Date), Segment 
                      ORDER BY SUM(Sales) DESC) as SalesRank
    FROM dbo.superstore_staging1
    WHERE Order_Date IS NOT NULL
    GROUP BY YEAR(Order_Date), MONTH(Order_Date), Segment, Product_ID, Product_Name, Category
),
TopProducts AS (
    SELECT 
        SalesYear,
        SalesMonth,
        Segment,
        Product_ID,
        Product_Name,
        Category,
        TotalSales,
        TotalQuantity,
        TotalProfit,
        OrderCount
    FROM MonthlySales
    WHERE SalesRank <= 5 -- Top 5 products per segment per month
)

SELECT 
    tp.SalesYear,
    tp.SalesMonth,
    DATENAME(MONTH, DATEFROMPARTS(tp.SalesYear, tp.SalesMonth, 1)) as MonthName,
    tp.Segment,
    tp.Product_ID,
    tp.Product_Name,
    tp.Category,
    tp.TotalSales,
    tp.TotalQuantity,
    tp.TotalProfit,
    tp.OrderCount,
    ROUND((tp.TotalSales / ms.TotalSegmentSales) * 100, 2) as SegmentSalesPercentage
FROM TopProducts tp
INNER JOIN (
    SELECT 
        SalesYear,
        SalesMonth,
        Segment,
        SUM(TotalSales) as TotalSegmentSales
    FROM MonthlySales
    GROUP BY SalesYear, SalesMonth, Segment
) ms ON tp.SalesYear = ms.SalesYear 
      AND tp.SalesMonth = ms.SalesMonth 
      AND tp.Segment = ms.Segment
ORDER BY tp.SalesYear DESC, tp.SalesMonth, tp.Segment, tp.TotalSales DESC;