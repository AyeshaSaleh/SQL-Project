SELECT City, COUNT(DISTINCT Customer_ID) AS Customer_Count
FROM superstore_staging1
GROUP BY City
HAVING COUNT(DISTINCT Customer_ID) > 10;