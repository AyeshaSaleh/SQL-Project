SELECT 
    c.Customer_ID, c.Customer_Name,o.Order_ID,o.Order_Date,o.Ship_Date,o.Product_Name,o.Sales,o.Quantity
FROM dbo.superstore_staging1 c
INNER JOIN dbo.superstore_staging1 o 
    ON c.Customer_ID = o.Customer_ID
    AND c.Customer_Name = o.Customer_Name
WHERE c.Row_ID < o.Row_ID 
ORDER BY c.Customer_Name, o.Order_Date;