SELECT City, COUNT(DISTINCT Customer_ID) AS Total_Customers
FROM superstore_staging1
GROUP BY City;