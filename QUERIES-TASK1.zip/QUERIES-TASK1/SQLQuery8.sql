SELECT Segment, AVG(Sales) AS Avg_Order_Value
FROM superstore_staging1
GROUP BY Segment;
