SELECT Customer_Name, City, Sales
FROM superstore_staging1
WHERE City IN ('New York', 'Los Angeles')
  AND Sales > 100;
