SELECT Category, SUM(Sales) AS Total_Sales
FROM superstore_staging1
GROUP BY Category;