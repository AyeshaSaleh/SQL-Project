SELECT 
c.Customer_ID,c.Customer_Name,c.Segment,c.Region,o.Order_ID,o.Order_Date,o.Ship_Date,p.Product_ID,
p.Product_Name,p.Category,p.Sub_Category,o.Sales,o.Quantity,o.Discount,o.Profit
FROM (
    SELECT DISTINCT Customer_ID, Customer_Name, Segment, Region 
    FROM dbo.superstore_staging1
) c
INNER JOIN dbo.superstore_staging1 o 
    ON c.Customer_ID = o.Customer_ID
INNER JOIN (
    SELECT DISTINCT Product_ID, Product_Name, Category, Sub_Category 
    FROM dbo.superstore_staging1
) p 
    ON o.Product_ID = p.Product_ID
ORDER BY c.Customer_Name, o.Order_Date, p.Product_Name;