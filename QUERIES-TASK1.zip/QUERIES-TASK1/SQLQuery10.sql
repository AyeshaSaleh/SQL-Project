SELECT YEAR(Order_Date) AS Order_Year, MONTH(Order_Date) AS Order_Month,
       MAX(Sales) AS Highest_Order, MIN(Sales) AS Lowest_Order
FROM superstore_staging1
GROUP BY YEAR(Order_Date), MONTH(Order_Date);