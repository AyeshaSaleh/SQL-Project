SELECT Customer_Name, City
FROM superstore_staging1
WHERE City = 'New York';
